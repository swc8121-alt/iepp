# IEPP L2 VM 스냅숏 시험 보고서

- 실행 ID: `l2-20261022034842-d78a5cb2`
- 생성 시각: 2026-10-22T04:10:44.906Z
- 실제 VM 실행: **예**
- 관측 수준: `VM_OBSERVED`
- 보안 주장 수준: `L1_REGISTRY_RELATIVE_CONTINUATION`
- 어댑터: virtualbox
- 통과: 22/22
- 증거 체인 head: `0dc34b7d6429ee3d99e9f89cf5dfd0efd360bd409318e81f67ac250510e6f197`

## 시나리오

- baseline_continue: 4/4
- rollback_after_accept: 4/4
- exact_replay: 4/4
- same_snapshot_fork: 6/6
- shared_current_credential_clone_first: 4/4

## 주장 경계

A real VM snapshot was restored, but the security result is only an L1 single-registry, registry-relative continuation decision. It does not identify the physical or original runtime.
런타임 원본성, clone-resistance, 하드웨어 신뢰루트, 암호학적 게스트 인증은 이 시험으로 증명하지 않습니다.
