# IEPP A3 2-VM 경쟁 시험 보고서

- 실행 ID: `a3-20261027050157-222dfc76`
- 생성 시각: 2026-10-27T05:29:11.317Z
- 실제 VM 실행: **예 — 서로 다른 VM 2개**
- 관측 수준: `TWO_VM_OBSERVED`
- 보안 주장 수준: `L1_REGISTRY_RELATIVE_CONTINUATION`
- 레지스트리: 별도 Node 프로세스 / HTTP
- 통과: 22/22
- 서버 관측 요청 겹침: 8/8
- CAS 구간 겹침: 0/8
- 증거 체인 head: `947895864ebc515e2a769029683919430fee33a3ff6c86f2f198a7c04f51fe29`

## 시나리오

- r1_baseline_continue: 2/2
- r2_fresh_order_ab: 3/3
- r3_fresh_order_ba: 3/3
- r4_controlled_race_fresh: 4/4
- r5_shared_challenge_ab: 2/2
- r6_shared_challenge_ba: 2/2
- r7_controlled_race_shared_challenge: 4/4
- r8_consumed_before_restore: 2/2

## 주장 경계

Two distinct VM snapshots and a separate HTTP registry process were exercised. The result remains an L1, registry-relative canonical-continuation observation; it does not identify a physical or original runtime.
런타임 원본성, clone-resistance, PUF/TEE/하드웨어 신뢰루트, 분산 합의, 복구 거버넌스, 독립적인 엔트로피 효과는 이 시험으로 증명하지 않습니다.
